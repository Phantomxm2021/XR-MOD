// // /*===============================================================================
// // Copyright (C) 2020 PhantomsXR Ltd. All Rights Reserved.
// //
// // This file is part of the AR-MOD SDK.
// //
// // The AR-MOD SDK cannot be copied, distributed, or made available to
// // third-parties for commercial purposes without written permission of PhantomsXR Ltd.
// //
// // Contact info@phantomsxr.com for licensing requests.
// // ===============================================================================*/

using Mirror;

namespace com.PhantomsXR.MirrorExtension.Runtime
{
    public class SyncUtility
    {
         public static void HandleSync(NetworkConnection _conn, NetworkStateMirror _networkState)
        {
            if (NetworkServer.active)
            {
                // Ignore all messages that do not match the server determined authority.
                if (_networkState.SmoothSync == null || _networkState.SmoothSync.netID.connectionToClient != _conn) return;

                // Always accept the first State so we have something to compare to. (if latestValidatedState == null)
                // Check each other State to make sure it passes the validation method. By default all States are accepted.
                // To tie in your own validation method, see the SmoothSyncMirrorExample scene and SmoothSyncMirrorExamplePlayerController.cs. 
                if (_networkState.SmoothSync.latestValidatedState == null ||
                    _networkState.SmoothSync.validateStateMethod(_networkState.state, _networkState.SmoothSync.latestValidatedState))
                {
                    _networkState.SmoothSync.latestValidatedState = _networkState.state;
                    _networkState.SmoothSync.latestValidatedState.receivedOnServerTimestamp = _networkState.SmoothSync.localTime;
                    _networkState.SmoothSync.SendStateToNonOwners(_networkState);
                    _networkState.SmoothSync.addState(_networkState.state);
                    _networkState.SmoothSync.checkIfOwnerHasChanged(_networkState.state);
                }
            }
            else
            {
                if (_networkState.SmoothSync != null && !_networkState.SmoothSync.hasControl)
                {
                    _networkState.SmoothSync.addState(_networkState.state);
                    _networkState.SmoothSync.checkIfOwnerHasChanged(_networkState.state);
                }
            }
        }

       
    }
}